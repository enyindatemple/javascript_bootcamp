// let userInput = prompt("Enter a value: ");
// userInput = userInput * 1;
// if (userInput > 130) alert("This is Noise");
// else if (userInput === 130) alert("Jackhammer");
// else if (userInput === 106) alert("Gas lawnmower");
// else if (userInput === 70) alert("Alarm Clock");
// else if (userInput > 106 && userInput < 130)
//   alert("Between Jackhammer and Gas lawnmower");

// const values = {
//   130: "Jackhammer",
//   106: "Gas lawnmower",
// };
// alert(values[userInput]);

// /61/
// v1
// const print = console.log;
// let userInput = prompt("Enter a value: ") * 1;
// let sum = 0;
// let count = 0;
// if (userInput === 0) print("First value can not be a 0");
// while (userInput !== 0) {
//   sum += userInput;
//   count += 1;
//   userInput = prompt("Enter a value: ") * 1;
// }
// print(sum);
// let avg = sum / count;
// print(avg);

// v1

// const print = console.log;
// let sum = 0;
// let count = 0;
// while (true) {
//   let userInput = prompt("Enter a value (0 to terminate):  ") * 1;
//   //   if (userInput === 0 && count === 0) {
//   //     print("Can't start with 0");
//   //     break;
//   //   } else if (userInput === 0) {
//   //     break;
//   //   }
//   if (userInput === 0) {
//     if (count === 0) {
//       print("Can't ...");
//     }
//     break;
//   }
//   sum += userInput;
//   count += 1;
// }
// print(sum);
// let avg = sum / count;
// print(avg);

// 83

// function calculateShippingPrice() {
//   console.log("Here");
// }
// console.log(h);
// var h = 45;

// let calculateShippingPrice = (noOfItems) => {
//   if (noOfItems === 1) return 10.95;
//   else return 10.95 + 2.95 * (noOfItems - 1);
// };
// let calculateShippingPrice = (noOfItems) => {
//   return noOfItems === 1 ? 10.95 : 10.95 + 2.95 * (noOfItems - 1);
// };
let calculateShippingPrice = (noOfItems) => 10.95 + 2.95 * (noOfItems - 1);

calculateShippingPrice(1);
